
givenDate := SYSDATE;
isEligible(7,givenDate);


